package top.niunaijun.blackbox.proxy;

import android.net.VpnService;

/**
 * Created by BlackBox on 2022/2/25.
 */
public class ProxyVpnService extends VpnService {

}
