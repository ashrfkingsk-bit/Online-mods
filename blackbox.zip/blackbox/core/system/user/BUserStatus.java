package top.niunaijun.blackbox.core.system.user;

/**
 * Created by Milk on 4/22/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public enum BUserStatus {
    ENABLE, DISABLE
}
